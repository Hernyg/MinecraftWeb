export const sampleLighting = (_x: number, _y: number, _z: number): number => {
  // TODO: Implement light propagation once block lighting is simulated.
  return 1;
};
