export class Physics {
  step(): void {
    // TODO: Implement physics integration for player and entities.
  }
}
