// TODO: Replace with UI layer once HUD integrates with a component system.
export const App = {};
